# PhishGuard Lite MVP

PhishGuard Lite is a Chrome extension + Node.js backend that helps non-technical users understand why an email may be phishing.

## What it does

- Watches Gmail Web for an opened email
- Extracts sender, subject, links, visible body text, and attachment names
- Sends indicators to a local backend
- Scores the email using heuristics + optional reputation lookups
- Shows a plain-English explanation in a side panel

## Current MVP scope

- Gmail Web only
- Chrome extension (Manifest V3)
- Plain-English reasoning
- Optional integrations for VirusTotal, AbuseIPDB, and MXToolbox

## Project structure

- `extension/` Chrome extension files
- `backend/` Node.js Express API

## Setup

### 1) Backend

```bash
cd backend
cp .env.example .env
npm install
npm start
```

Backend runs on `http://localhost:3000`.

Add your API keys into `.env`:

- `VIRUSTOTAL_API_KEY`
- `ABUSEIPDB_API_KEY`
- `MXTOOLBOX_API_KEY`

The app still works without them, but external reputation checks will be skipped.

### 2) Chrome extension

- Open Chrome
- Go to `chrome://extensions`
- Enable **Developer mode**
- Click **Load unpacked**
- Select the `extension/` folder
- Open Gmail in Chrome
- Open an email and wait a few seconds for the panel to appear

## Important limitations

- Gmail DOM changes can break extraction logic
- Full email headers are not accessible from normal Gmail DOM scraping
- The MVP focuses on visible content and visible links
- Some reputation APIs have rate limits and billing requirements
- A clean reputation result does **not** prove an email is safe

## Suggested next upgrades

- Outlook Web support
- Better Gmail extraction logic via Gmail API or Workspace add-on approach
- Header parser for SPF/DKIM/DMARC analysis
- Domain age checks and WHOIS enrichment
- LLM or classifier-based explanation engine
- Admin dashboard and feedback loop for false positives
