const BACKEND_URL = 'http://localhost:3000/api/analyze-email';
const BRAND_DOMAINS = ['microsoft.com', 'paypal.com', 'docusign.com', 'amazon.com', 'google.com', 'apple.com'];

let lastSignature = null;
let currentEmail = null;
let root = null;

function ensurePanel() {
  if (root) return root;
  root = document.createElement('div');
  root.id = 'phishguard-root';
  root.className = 'phg-hidden';
  root.innerHTML = `
    <div class="phg-header">
      <div class="phg-topbar">
        <div>
          <h2>PhishGuard Lite</h2>
          <div class="phg-subtitle">Plain-English phishing reasoning for Gmail</div>
        </div>
        <button id="phg-refresh" class="phg-btn">Refresh</button>
      </div>
    </div>
    <div id="phg-content" class="phg-loading">Open an email to analyze it.</div>
  `;
  document.body.appendChild(root);
  root.querySelector('#phg-refresh').addEventListener('click', () => {
    if (currentEmail) analyzeAndRender(currentEmail, true);
  });
  return root;
}

function showPanel() {
  ensurePanel().classList.remove('phg-hidden');
}

function setContent(html) {
  ensurePanel().querySelector('#phg-content').innerHTML = html;
}

function textOrEmpty(el) {
  return (el?.innerText || el?.textContent || '').trim();
}

function extractLinks(emailBodyNode) {
  const anchors = [...(emailBodyNode?.querySelectorAll('a') || [])];
  return anchors.map((a) => ({
    text: textOrEmpty(a).slice(0, 120),
    href: a.href || ''
  })).filter((x) => x.href);
}

function collectEmailFromGmail() {
  const subjectNode = document.querySelector('h2[data-thread-perm-id]') || document.querySelector('h2.hP');
  const bodyNode = document.querySelector('div[role="listitem"] div.a3s') || document.querySelector('div.a3s');
  const fromNode = document.querySelector('span[email]');
  const fromEmail = fromNode?.getAttribute('email') || '';
  const fromName = textOrEmpty(document.querySelector('span.gD')) || fromEmail;
  const snippet = textOrEmpty(bodyNode).slice(0, 8000);
  const subject = textOrEmpty(subjectNode);
  const links = extractLinks(bodyNode);
  const attachments = [...document.querySelectorAll('div[download_url]')].map((el) => {
    const raw = el.getAttribute('download_url') || '';
    const parts = raw.split(':');
    return { filename: parts[1] || 'attachment' };
  });

  if (!subject && !snippet && !fromEmail) return null;

  return {
    source: 'gmail-web',
    subject,
    fromName,
    fromEmail,
    replyTo: '',
    returnPath: '',
    authentication: {},
    bodyText: snippet,
    links,
    attachments,
    observedBrandDomains: BRAND_DOMAINS.filter((d) => snippet.toLowerCase().includes(d.split('.')[0]))
  };
}

function scoreClass(score) {
  if (score >= 75) return 'high';
  if (score >= 25) return 'medium';
  return 'low';
}

function escapeHtml(str) {
  return (str || '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

function renderResult(result) {
  const reasons = (result.reasons || []).map((r) => `<li>${escapeHtml(r)}</li>`).join('');
  const userActions = (result.userActions || []).map((r) => `<li>${escapeHtml(r)}</li>`).join('');
  const indicators = Object.entries(result.technicalDetails || {}).map(([k, v]) => (
    `<div class="phg-keyval"><strong>${escapeHtml(k)}</strong><br>${escapeHtml(String(v))}</div>`
  )).join('');

  setContent(`
    <div class="phg-section">
      <div class="phg-score ${scoreClass(result.riskScore)}">${escapeHtml(result.verdict)} • ${result.riskScore}/100</div>
      <div class="phg-muted" style="margin-top:10px;">Confidence: ${escapeHtml(result.confidence || 'medium')}</div>
    </div>
    <div class="phg-section">
      <h3>Why this looks risky</h3>
      <ul class="phg-list">${reasons || '<li>No strong phishing indicators were found in the visible content.</li>'}</ul>
    </div>
    <div class="phg-section">
      <h3>What you should do</h3>
      <ul class="phg-list">${userActions || '<li>Use normal caution before clicking links or opening attachments.</li>'}</ul>
    </div>
    <div class="phg-section">
      <h3>Technical details</h3>
      <div class="phg-grid">${indicators}</div>
    </div>
  `);
}

async function analyzeAndRender(email, force = false) {
  const signature = JSON.stringify({ subject: email.subject, fromEmail: email.fromEmail, bodyText: email.bodyText.slice(0, 500) });
  if (!force && signature === lastSignature) return;
  lastSignature = signature;
  currentEmail = email;
  showPanel();
  setContent('<div class="phg-loading">Analyzing email content, links, and sender indicators...</div>');

  try {
    const res = await fetch(BACKEND_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(email)
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(text || 'Backend error');
    }

    const result = await res.json();
    renderResult(result);
  } catch (err) {
    setContent(`
      <div class="phg-error">
        <strong>Could not analyze the email.</strong><br><br>
        ${escapeHtml(err.message)}<br><br>
        Make sure the backend is running on <code>http://localhost:3000</code>.
      </div>
    `);
  }
}

function pollForEmail() {
  ensurePanel();
  const email = collectEmailFromGmail();
  if (email) analyzeAndRender(email);
}

setInterval(pollForEmail, 2500);
window.addEventListener('load', pollForEmail);
