import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { analyzeEmail } from './services/analyzeEmail.js';

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'phishguard-backend' });
});

app.post('/api/analyze-email', async (req, res) => {
  try {
    const result = await analyzeEmail(req.body || {}, {
      virustotalApiKey: process.env.VIRUSTOTAL_API_KEY,
      abuseipdbApiKey: process.env.ABUSEIPDB_API_KEY,
      mxtoolboxApiKey: process.env.MXTOOLBOX_API_KEY
    });

    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: 'analysis_failed',
      message: error.message || 'Unexpected analysis error'
    });
  }
});

app.listen(port, () => {
  console.log(`PhishGuard backend listening on http://localhost:${port}`);
});
