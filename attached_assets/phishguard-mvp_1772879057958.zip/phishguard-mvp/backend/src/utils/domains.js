export function safeUrl(raw) {
  try {
    return new URL(raw);
  } catch {
    return null;
  }
}

export function getDomainFromEmail(email) {
  if (!email || !email.includes('@')) return '';
  return email.split('@').pop().toLowerCase().trim();
}

export function getBaseDomain(hostname) {
  if (!hostname) return '';
  const parts = hostname.toLowerCase().split('.').filter(Boolean);
  if (parts.length <= 2) return parts.join('.');
  return parts.slice(-2).join('.');
}

export function normalizeText(input) {
  return (input || '').replace(/\s+/g, ' ').trim();
}

export function includesBrand(body, brands) {
  const text = normalizeText(body).toLowerCase();
  return brands.filter((brand) => text.includes(brand));
}
