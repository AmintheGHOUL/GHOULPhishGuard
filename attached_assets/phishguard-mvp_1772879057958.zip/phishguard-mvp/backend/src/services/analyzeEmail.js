import { analyzeContent } from './contentRules.js';
import { checkVirusTotalForUrl, checkAbuseIp, checkMxToolbox, extractFirstHttpLink, findDomainMismatch } from './reputation.js';
import { safeUrl, getDomainFromEmail, getBaseDomain } from '../utils/domains.js';

function detectSuspiciousAttachments(attachments = []) {
  const riskyExts = ['.zip', '.exe', '.js', '.iso', '.html', '.docm', '.xlsm', '.scr'];
  const found = attachments
    .map((a) => a.filename || '')
    .filter((name) => riskyExts.some((ext) => name.toLowerCase().endsWith(ext)));

  return {
    score: found.length ? 12 : 0,
    findings: found.length ? [`This email contains risky attachment types: ${found.join(', ')}.`] : []
  };
}

function detectLinkDeception(links = [], observedBrands = []) {
  let score = 0;
  const findings = [];
  const technical = {};

  for (const link of links) {
    const parsed = safeUrl(link.href);
    if (!parsed) continue;
    const baseDomain = getBaseDomain(parsed.hostname);

    if (link.text && /^https?:/i.test(link.text) && link.text !== link.href) {
      score += 15;
      findings.push('A visible link does not match the real destination behind it.');
    }

    for (const brand of observedBrands) {
      if (parsed.hostname.toLowerCase().includes(brand.split('.')[0]) && baseDomain !== brand) {
        score += 25;
        findings.push(`A link tries to look like ${brand}, but the real website is ${baseDomain}.`);
      }
    }

    technical.primaryLinkDomain = baseDomain;
    technical.primaryLink = link.href;
  }

  return { score, findings, technical };
}

function verdictFromScore(score) {
  if (score >= 75) return 'Likely phishing';
  if (score >= 50) return 'High risk';
  if (score >= 25) return 'Suspicious';
  return 'Low risk';
}

function confidenceFromScore(score) {
  if (score >= 75) return 'high';
  if (score >= 40) return 'medium';
  return 'low';
}

function dedupe(items) {
  return [...new Set(items)].slice(0, 8);
}

function extractIpFromBody(bodyText = '') {
  const match = bodyText.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/);
  return match?.[0] || '';
}

export async function analyzeEmail(email, apiKeys) {
  const bodyText = email.bodyText || '';
  const subject = email.subject || '';
  const fromEmail = (email.fromEmail || '').toLowerCase();
  const replyTo = (email.replyTo || '').toLowerCase();
  const returnPath = (email.returnPath || '').toLowerCase();
  const attachments = email.attachments || [];
  const links = email.links || [];
  const observedBrands = email.observedBrandDomains || [];
  const senderDomain = getDomainFromEmail(fromEmail);
  const senderBaseDomain = getBaseDomain(senderDomain);

  let score = 0;
  const reasons = [];
  const technicalDetails = {
    sender: fromEmail || 'unknown',
    subject: subject || 'none',
    linksFound: links.length,
    attachmentsFound: attachments.length,
    senderDomain: senderBaseDomain || 'unknown'
  };

  const contentAnalysis = analyzeContent(bodyText, subject);
  score += contentAnalysis.score;
  reasons.push(...contentAnalysis.findings);

  const attachmentAnalysis = detectSuspiciousAttachments(attachments);
  score += attachmentAnalysis.score;
  reasons.push(...attachmentAnalysis.findings);

  const mismatch = findDomainMismatch(fromEmail, replyTo, returnPath);
  if (mismatch.replyMismatch) {
    score += 20;
    reasons.push(`The reply address belongs to ${mismatch.replyDomain}, which does not match the sender's domain.`);
  }
  if (mismatch.returnPathMismatch) {
    score += 12;
    reasons.push(`The return-path belongs to ${mismatch.returnPathDomain}, which is different from the sender's domain.`);
  }

  Object.assign(technicalDetails, {
    replyToDomain: mismatch.replyDomain || 'not available',
    returnPathDomain: mismatch.returnPathDomain || 'not available'
  });

  const linkAnalysis = detectLinkDeception(links, observedBrands);
  score += linkAnalysis.score;
  reasons.push(...linkAnalysis.findings);
  Object.assign(technicalDetails, linkAnalysis.technical);

  const firstUrl = extractFirstHttpLink(links);
  const extractedIp = extractIpFromBody(bodyText);

  const [vtResult, abuseResult, mxResult] = await Promise.all([
    checkVirusTotalForUrl(firstUrl, apiKeys.virustotalApiKey),
    checkAbuseIp(extractedIp, apiKeys.abuseipdbApiKey),
    checkMxToolbox(senderBaseDomain, apiKeys.mxtoolboxApiKey)
  ]);

  if (vtResult.checked && (vtResult.malicious > 0 || vtResult.suspicious > 0)) {
    score += 20;
    reasons.push('A threat-intelligence source has flagged the email link as suspicious or malicious.');
  }

  if (abuseResult.checked && abuseResult.abuseConfidenceScore >= 50) {
    score += 15;
    reasons.push('The related IP address has a high abuse score.');
  }

  if (mxResult.checked && (!mxResult.spfOk || !mxResult.dmarcOk)) {
    score += 8;
    reasons.push('The sender domain has weak email-security records or they could not be verified cleanly.');
  }

  Object.assign(technicalDetails, {
    virusTotal: vtResult.checked ? `malicious=${vtResult.malicious}, suspicious=${vtResult.suspicious}` : 'not checked',
    abuseIpdb: abuseResult.checked ? `score=${abuseResult.abuseConfidenceScore}, reports=${abuseResult.totalReports}` : 'not checked',
    mxToolbox: mxResult.checked ? `spf=${mxResult.spfOk}, dmarc=${mxResult.dmarcOk}, mx=${mxResult.mxOk}` : 'not checked'
  });

  score = Math.max(0, Math.min(100, score));

  const userActions = [];
  if (score >= 50) {
    userActions.push('Do not click links or open attachments in this email.');
    userActions.push('Verify the request using the company’s real website or phone number.');
  } else if (score >= 25) {
    userActions.push('Be careful with links and verify the sender before taking action.');
  } else {
    userActions.push('No strong phishing signal was found in the visible content, but keep normal caution.');
  }

  return {
    riskScore: score,
    verdict: verdictFromScore(score),
    confidence: confidenceFromScore(score),
    reasons: dedupe(reasons),
    userActions: dedupe(userActions),
    technicalDetails
  };
}
