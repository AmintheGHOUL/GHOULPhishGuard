import { safeUrl, getBaseDomain } from '../utils/domains.js';

async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.json();
}

export async function checkVirusTotalForUrl(rawUrl, apiKey) {
  if (!apiKey || !rawUrl) return { checked: false };
  const encoded = Buffer.from(rawUrl).toString('base64url');
  const url = `https://www.virustotal.com/api/v3/urls/${encoded}`;
  try {
    const data = await fetchJson(url, { headers: { 'x-apikey': apiKey } });
    const stats = data?.data?.attributes?.last_analysis_stats || {};
    return {
      checked: true,
      malicious: Number(stats.malicious || 0),
      suspicious: Number(stats.suspicious || 0),
      harmless: Number(stats.harmless || 0),
      reputation: data?.data?.attributes?.reputation ?? 0
    };
  } catch {
    return { checked: false };
  }
}

export async function checkAbuseIp(ip, apiKey) {
  if (!apiKey || !ip) return { checked: false };
  try {
    const data = await fetchJson(`https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(ip)}&maxAgeInDays=90`, {
      headers: {
        Key: apiKey,
        Accept: 'application/json'
      }
    });

    return {
      checked: true,
      abuseConfidenceScore: Number(data?.data?.abuseConfidenceScore || 0),
      totalReports: Number(data?.data?.totalReports || 0),
      usageType: data?.data?.usageType || 'unknown'
    };
  } catch {
    return { checked: false };
  }
}

export async function checkMxToolbox(domain, apiKey) {
  if (!apiKey || !domain) return { checked: false };
  try {
    const headers = { Authorization: apiKey };
    const [spf, dmarc, mx] = await Promise.all([
      fetchJson(`https://api.mxtoolbox.com/api/v1/Lookup/spf/${domain}`, { headers }).catch(() => null),
      fetchJson(`https://api.mxtoolbox.com/api/v1/Lookup/dmarc/${domain}`, { headers }).catch(() => null),
      fetchJson(`https://api.mxtoolbox.com/api/v1/Lookup/mx/${domain}`, { headers }).catch(() => null)
    ]);

    return {
      checked: true,
      spfOk: !!spf,
      dmarcOk: !!dmarc,
      mxOk: !!mx
    };
  } catch {
    return { checked: false };
  }
}

export function extractFirstHttpLink(links = []) {
  const link = links.find((x) => safeUrl(x.href));
  return link?.href || '';
}

export function findDomainMismatch(fromEmail, replyTo, returnPath) {
  const senderDomain = getBaseDomain(fromEmail.split('@')[1] || '');
  const replyDomain = getBaseDomain(replyTo.split('@')[1] || '');
  const returnPathDomain = getBaseDomain(returnPath.split('@')[1] || '');

  return {
    senderDomain,
    replyDomain,
    returnPathDomain,
    replyMismatch: !!replyDomain && !!senderDomain && replyDomain !== senderDomain,
    returnPathMismatch: !!returnPathDomain && !!senderDomain && returnPathDomain !== senderDomain
  };
}
